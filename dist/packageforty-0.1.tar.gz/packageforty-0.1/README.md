#Building package locally
python setup.py sdist'

## installing this package from github
pip install git+https://github.com/sixolile/mypackage

## update this package from github
pip install --upgrade git+https://github.com/sixolile/mypackage

python setup.py sdist